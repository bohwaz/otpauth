<?php 
require_once('../iso-646.ivcs.clean.php');

global $ivcs;
global $rev_ivcs;


foreach ($rev_ivcs as $k=>$v) {
  if ($k!=$ivcs[$v]) {
    print "Stopp at $k|$v\n";
    exit();
  } else {
    print "$k|".$ivcs[$v]."|$v\n";
  }

}


