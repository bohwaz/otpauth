<?php

 $user_id = "";

 //query database for user
 //db_query ...

 //show preferences available
 print "<a href='theme.php?user_id=$user_id'>Change theme</a>";
 print "<br/>";
 print "<a href='gen_otp.php?user_id=$user_id'>Change theme</a>";



?>
